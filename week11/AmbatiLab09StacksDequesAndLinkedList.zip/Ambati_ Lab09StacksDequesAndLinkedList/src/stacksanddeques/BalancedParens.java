/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stacksanddeques;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author S524965
 */
public class BalancedParens {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        AStack<Character> parenStack;
        
        
        Scanner scan=new Scanner(new File("expressions.txt"));
        boolean flag=false;
        while(scan.hasNext()){
            parenStack=new AStack<Character>();
            //System.out.println("TOP:"+parenStack.peek()+"  "+parenStack.size());
            String str=scan.nextLine();
            
           
            for(int i=0;i<str.length();i++){
                if(str.charAt(i)=='('){
                    parenStack.push(str.charAt(i));
                }
                else if(str.charAt(i)==')'){
                    if(!parenStack.isEmpty()){
                    parenStack.pop();
                    }
                    else{
                        flag=false;
                        System.out.println(str+" : INVALID:\nTrying to pop, but the stack is empty!");
                        break;
                    }
                }
                else{
                    flag=true;
                }
                
                
            }
            
            if(parenStack.isEmpty()&&flag==true){
                System.out.println(str+" : VALID");
            }
            else{
               // System.out.println(str+" : INVALID");
                if(!parenStack.isEmpty()){
                if(parenStack.peek()=='('){
                    System.out.println(str+" : INVALID:\nParsing complete, but the stack is not empty!");
                }
                }
                
            }
           
            System.out.println("");
            
        }
        
    }
    
}

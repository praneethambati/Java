/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package motelrental;

/**
 *
 * @author Sai Praneeth,Ambati -S524965
 */
public class MotelRental {
    private double standardMotelRentalAmount;
    private double seasonalRate;
    private double yearlyDiscount;

    /**
     * This is a parameterized constructor taking three arguments 
     * @param standardMotelRentalAmount it has the standard motel rent amount.
     * @param seasonalRate contains the seasonal rate percentage
     * @param yearlyDiscount has the yearly discount percentage.
     */
    public MotelRental(double standardMotelRentalAmount, double seasonalRate, double yearlyDiscount) {
        this.standardMotelRentalAmount = standardMotelRentalAmount;
        this.seasonalRate = seasonalRate;
        this.yearlyDiscount = yearlyDiscount;
    }

    /**
     * This is a getter method that returns the seasonal rate percentage.
     * @return returns the seasonal rate percentage
     */
    public double getSeasonalRate() {
        return seasonalRate;
    }
    
    /**
     * This is a getter method that returns the standard motel rental amount.
     * @return returns the standard motel rent amount.
     */
    public double getStandardMotelRentalAmount() {
        return standardMotelRentalAmount;
    }

    /**
     * This is a getter method that returns the yearly discount percentage.
     * @return returns the yearly discount percentage.
     */
    public double getYearlyDiscount() {
        return yearlyDiscount;
    }
    
    /**
     * This is a getter method that calculates the standard motel rent amount by taking the month number as input
     * @param month contain the month to which rent needs to be calculated
     * @return returns the standard motel rent amount depending upon the month.
     */
    public double getMonthlyRental(int month){
        if(month==0||month==11){
            return ((standardMotelRentalAmount*seasonalRate)+standardMotelRentalAmount);
        }
       
            return standardMotelRentalAmount;
    
    }
    
    /**
     * This is a getter method that return the yearly rental of the motel.
     * @return returns the yearly rental for twelve months.
     */
    public double getYearlyRental(){
        return ((standardMotelRentalAmount*12)-((standardMotelRentalAmount*12*yearlyDiscount)));
    }
    
    /**
     * This is a getter method that calculates the total charged for month .It take month and number of months as the input.
     * @param month has the month number which is the month lease start month.
     * @param numberOfMonths contains the number of months.
     * @return returns the monthly rental by taking month number and number of months.
     */
    public double getMonthlyRental(int month,int numberOfMonths){
        
 int years=numberOfMonths/12;
        int months2=numberOfMonths%12;
       double YearlyRental2=years*getYearlyRental();
       
       int i=month;
       int count=0;
       while(count<months2)
       {
           if(i==12){
               i=0;
           }
           YearlyRental2+=getMonthlyRental(i);
           i++;
           count++;
       }
       return YearlyRental2;
    
}
    /**
     * This is a to string method that returns a string containing motel rental details,seasonal rate and yearly discount.
     * @return returns a string that has the motel rental fee, seasonal rate and yearly discount.
     */
    @Override
    public String toString(){
        return "Motel rental fee is $"+this.standardMotelRentalAmount+"; the seasonal rate is "+this.seasonalRate+"; the yearly discount is "+this.yearlyDiscount;
    }
    
}

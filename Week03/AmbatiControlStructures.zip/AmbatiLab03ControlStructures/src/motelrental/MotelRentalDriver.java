/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package motelrental;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Sai Praneeth,Ambati - S524965
 */
public class MotelRentalDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
            throws FileNotFoundException {
         Scanner inMotelData=new Scanner(new File("motelData.txt"));
         
        
      
       while(inMotelData.hasNext()){
           
            int standardRent=inMotelData.nextInt();
            double seasonalRate=inMotelData.nextDouble();
            double yearlyDiscount=inMotelData.nextDouble();
            
             MotelRental mr=new MotelRental(standardRent, seasonalRate, yearlyDiscount);
             
            System.out.println("\nNEW MOTEL ROOM CREATED:");
            System.out.println(mr);
            
            System.out.println("");
            System.out.println("TESTING GETTERS");
            System.out.println("Standard rental fee = "+mr.getStandardMotelRentalAmount());
            System.out.println("Seasonal rate = "+mr.getSeasonalRate());
            System.out.println("Yearly discount = "+mr.getYearlyDiscount());
            System.out.println("");
            
            System.out.println("TESTING getMonthlyRental(int month)");
            for(int i=0;i<=11;i++){
            System.out.println("Rental fee for month "+i+" is "+mr.getMonthlyRental(i));
            }
            System.out.println("");
            
            System.out.println("TESTING getYearlyRental()");
            System.out.println("Yearly rental fee = "+mr.getYearlyRental());
            System.out.println("");
            Scanner inMonthData=new Scanner(new File("monthData.txt"));
            while(inMonthData.hasNext()){
                int month=inMonthData.nextInt();
                int numberofmonths=inMonthData.nextInt();
            System.out.println("Rental fee for "+numberofmonths+" months, beginning with month "+month+" is "+ mr.getMonthlyRental(month, numberofmonths));
        
            }
           inMonthData.close();
             
           
       }
       inMotelData.close();
       
    }
    
}

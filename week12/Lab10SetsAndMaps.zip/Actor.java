/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package setsandmaps;

/**
 *
 * @author Instructor
 */
public class Actor
{
    private String lastName;
    private String firstName;

    public Actor(String lastName, String firstName) 
    {
        this.lastName = lastName;
        this.firstName = firstName;
    }
}

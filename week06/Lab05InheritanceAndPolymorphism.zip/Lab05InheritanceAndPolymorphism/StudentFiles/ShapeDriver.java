/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shape;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Instructor
 */
public class ShapeDriver 
{
    public static void main(String[] args) throws FileNotFoundException 
    {
//     declare and initialize a Scanner object named scanner to 
//     read from the file shapes.txt  
//     declare four double variable such as length, breadth, radius, and side 
//     to store the scanned values
//     while shapes.txt has more data 
//       {
//           Read in the data from the text file and store those values in 
//           respective variable.
//           The values in the text file are of double type.       
//           The first value in the text file is the length of the rectangle, 
//           second value is the breadth of the rectangle, 
//           third value is the side of the square,
//           and the fourth value is radius of the circle.       
//           Create an object for Rectangle and pass the length and breadth 
//           values as arguments.    
//           Create an object for Circle and pass the radius as argument
//           Create an object for Square and pass the side as argument
//           Print the toString, Area and Perimeter of the Rectangle, 
//           Square and Circle respectively.
//               
//      }     
//      scanner.close();
    }     
}       

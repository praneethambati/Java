/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab06abstractandinterfaces;

/**
 *
 * @author S524965
 */
public class Student extends AbstractStudent implements Employee,Employer{
    private String nameOfInstitution;
    private int hoursWorked;
    private double hourlyRate;
    private int numOfEmployees;
    private int years;
    
    /**
     * This a constructor for Student class taking seven parameters
     * @param nameOfStudent contains the name of the student
     * @param annualTuition contains the annual tuition fee
     * @param years contains the year value.
     * @param nameOfInstitution contains the name of the institution
     * @param hoursWorked contains the number of hours worked.
     * @param hourlyRate contains the rate per one hour.
     * @param numOfEmployees  contains the number of employees.
     */
    public Student(String nameOfStudent,double annualTuition,int years,String nameOfInstitution,int hoursWorked,double hourlyRate,int numOfEmployees) {
        super(nameOfStudent, annualTuition);
        this.years = years;
        this.nameOfInstitution = nameOfInstitution;
        this.hoursWorked = hoursWorked;
        this.hourlyRate = hourlyRate;
        this.numOfEmployees = numOfEmployees;
       
    }
    
    /**
     * This is a toString method that has been overridden with a user specified string format.
     * @return returns the toString method string value from super class concatenated with this class toString method containing years,name of institution, hours worked, hourly rate, number of employees.
     */
    @Override
    public String toString(){
        return super.toString()+String.format(" %4d %-20s %4d %10.2f %4d",this.years,this.nameOfInstitution,this.hoursWorked,this.hourlyRate,this.numOfEmployees );
    }
    
    /**
     * This is getter method that overrides the super class, calculates and returns the total tuition fee.
     * @return returns the total tuition fee.
     */
    @Override
    public double getTuition(){
      return  this.years*super.getAnnualTuition();
    }
    
    /**
     * This is a getter method that overrides the super class, calculates and returns the weekly salary.
     * @return returns the weekly salary.
     */
    @Override
    public double getWeeklySalary(){
        return this.hourlyRate*this.hoursWorked*7;
    }
    
    /**
     * This is a getter method that overrides the super class and returns the number of employees.
     * @return returns the number of employees.
     */
    @Override
    public int getNumOfEmployees(){
        return this.numOfEmployees;
    }
    
    /**
     * This is a setter method that overrides the super class and  sets the number of employees.
     * @param number contains the number that needs to be set the number of employees.
     */
    @Override
    public void setNumOfEmployees(int number){
        this.numOfEmployees=number;
    }

    
    
    
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab06abstractandinterfaces;

/**
 *
 * @author S524965
 */
public abstract class AbstractStudent {
    private String nameOfStudent;
    private double annualTuition;
    
    /**
     * This is constructor for AbstractStudent class taking two parameters.
     * @param nameOfStudent contains the name of the student
     * @param annualTuition contains the annual tuition fee.
     */
    public AbstractStudent(String nameOfStudent, double annualTuition) {
        this.nameOfStudent = nameOfStudent;
        this.annualTuition = annualTuition;
    }

    /**
     * This is getter method that returns the Annual tuition fee.
     * @return returns the annual tuition fee
     */
    public double getAnnualTuition() {
        return annualTuition;
    }
    
    /**
     * This is a abstract getter method that returns double value.
     * @return returns a double value.
     */
    public abstract double getTuition();
        
    /**
     * This is a toString method that is overridden with a user specified string format.
     * @return returns the name of student and annual tuition fee in a specific string format.
     */
    @Override
    public String toString(){
        return String.format("%-20s%10.2f", nameOfStudent,getAnnualTuition());
    }
}

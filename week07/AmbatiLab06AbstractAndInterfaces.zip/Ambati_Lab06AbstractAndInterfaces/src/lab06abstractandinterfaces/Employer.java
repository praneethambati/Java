/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab06abstractandinterfaces;

/**
 *
 * @author S524965
 */
public interface Employer {
    /**
     * This is a getter method of number of employees that returns int value
     * @return returns int value.
     */
    public int getNumOfEmployees();
    
    /**
     * This is a setter method of number of employees
     * @param number contains the number that has to be set for the number of employees.
     */
    public void setNumOfEmployees(int number);
}

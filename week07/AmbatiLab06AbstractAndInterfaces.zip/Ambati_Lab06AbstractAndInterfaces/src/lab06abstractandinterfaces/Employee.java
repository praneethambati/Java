/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab06abstractandinterfaces;

/**
 *
 * @author S524965
 */
public interface Employee {
    /**
     * This is a getter method that returns a double value.
     * @return returns a double value.
     */
    public double getWeeklySalary();
}

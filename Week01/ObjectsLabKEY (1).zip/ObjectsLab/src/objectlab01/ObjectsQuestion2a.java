/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objectlab01;
import java.math.*;
/**
 *
 * @author Instructor
 */
public class ObjectsQuestion2a 
{
    public static void main(String[] args) 
    {
        double myDoubleValue = 36.0;
        System.out.println("\nSolution 2a");
        System.out.println("The square root of "+myDoubleValue+" is "
                 +Math.sqrt(myDoubleValue));
    }
}

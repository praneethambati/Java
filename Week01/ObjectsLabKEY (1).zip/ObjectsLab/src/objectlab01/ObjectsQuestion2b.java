/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objectlab01;

/**
 *
 * @author Instructor
 */
public class ObjectsQuestion2b 
{
    public static void main(String[] args) 
    {
        double myDoubleValue1 = 0.5;
        double myDoubleValue2 = 0.75;
        System.out.println("\nSolution 2b");
        System.out.println("Sine of "+myDoubleValue1+" is "
                 +Math.sin(myDoubleValue1));
        System.out.println("Sine of "+myDoubleValue2+" is "
                 +Math.sin(myDoubleValue2));
        System.out.println("Tan of "+myDoubleValue1+" is "
                 +Math.tan(myDoubleValue1));
        System.out.println("Tan of "+myDoubleValue2+" is "
                 +Math.tan(myDoubleValue2));
    }
}

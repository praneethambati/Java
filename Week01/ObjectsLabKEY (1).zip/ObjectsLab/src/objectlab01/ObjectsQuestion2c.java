/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objectlab01;

/**
 *
 * @author Instructor
 */
public class ObjectsQuestion2c 
{
    public static void main(String[] args) 
    {
        int myIntNumber1 = 2;
        int myIntNumber2 = 5;
        System.out.println("\nSolution 2c");
        System.out.println(myIntNumber1+" raised to power "+myIntNumber2+" is "
                 +Math.pow(myIntNumber1,myIntNumber2));
    }
}

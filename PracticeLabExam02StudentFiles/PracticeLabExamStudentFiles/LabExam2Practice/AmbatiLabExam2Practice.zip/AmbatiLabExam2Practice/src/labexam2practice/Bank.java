/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labexam2practice;
import java.util.*;
/**
 *
 * @author s524965
 */
public class Bank {
    Queue<Customer> waiters;
    Map<String,Integer> accounts;
    private int served;
    private int totalWaitTime;

    public Bank() {
        this.waiters=new LinkedList<Customer>();
        this.accounts=new HashMap<String,Integer>();
        this.served=0;
        this.totalWaitTime=0;
    }
   
    
    public double averageWait() {
        return ((double)totalWaitTime/served);
    }
    
    public String addToLine(String name, int transactionValue){
        Customer a=new Customer(name,transactionValue);
        waiters.add(a);
        
        return "Customer added to line: "+ a;
    }

    public String serve(){
        if(waiters.isEmpty()){
            return "No one waiting";
        }
       
           Customer x=waiters.remove();
          totalWaitTime+=x.getWait();
          served++;
          recordTransaction(x);
          return "Served Customer:"+x;
            
      
    }
    
    public String bumpTime(){
        
       Iterator<Customer> itr=waiters.iterator();
       while(itr.hasNext()){
           itr.next().bumpWaitTime();
       }
        return "All wait times increased";
    }
    
    public int numberWaiting(){
        return waiters.size();
    }
    
    private void recordTransaction(Customer c){
       if(accounts.containsKey(c.getName())){
          accounts.put(c.getName(),accounts.get(c.getName())+c.getTransactionValue());
      }else{
      accounts.put(c.getName(),c.getTransactionValue());
       } 
    }
    
    public List<String> customersOver(int low){
        List<String> namesIn=new ArrayList<String>();
        for(String m: accounts.keySet()){
            if(accounts.get(m)>low){
                namesIn.add(m);
            }
        }
        return namesIn;
    }
    
     
    @Override
    public String toString() {
        return "Bank{" + "waiters=" + waiters +
                ", \n\taccounts=" + accounts + 
                ", \n\tserved=" + served +
                ", totalWaitTime=" + totalWaitTime + '}';
    }
    
}

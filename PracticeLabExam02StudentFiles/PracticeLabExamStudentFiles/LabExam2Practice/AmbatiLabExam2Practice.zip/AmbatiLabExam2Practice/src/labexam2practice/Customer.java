/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labexam2practice;

/**
 *
 * @author s524965
 */
class Customer {
    private String name;
    private int transactionValue;
    private int wait;

    public Customer(String name, int transactionValue) {
        this.name = name;
        this.transactionValue = transactionValue;
        this.wait=0;
    }

    public String getName() {
        return name;
    }

    public int getTransactionValue() {
        return transactionValue;
    }

    public int getWait() {
        return wait;
    }

    @Override
    public String toString() {
        return "Customer{" + "name=" + name + ", transactionValue=" + transactionValue + ", wait=" + wait + '}';
    }
    
    public void bumpWaitTime(){
        wait++;
    }
    
    
}

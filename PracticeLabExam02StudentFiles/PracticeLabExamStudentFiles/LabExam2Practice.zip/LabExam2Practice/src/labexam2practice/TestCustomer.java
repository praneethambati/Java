/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labexam2practice;

import java.io.*;
import java.util.*;
import static labexam2practice.TestBank.aCustomer;
import static labexam2practice.TestBank.printLineHeader;
import static labexam2practice.TestBank.testFor;

/**
 *
 * @author HOOT
 */
public class TestCustomer {
    
    public static Set<String> testFor = new HashSet<String>();
    public static Customer aCustomer = null;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        
        String name = "Customer.txt";
    
        Scanner in = new Scanner(new File(name));
        
        testFor.add("Customer:Constructor");
        testFor.add("Customer:getName");
        testFor.add("Customer:getTransactionValue");
        testFor.add("Customer:getWait");
        testFor.add("Customer:bumpWaitTime");
        testFor.add("Customer:toString");
         
        while(in.hasNext()){
            String line = in.nextLine();
            processLine(line);
        }
    }
    
    public static void processLine(String line){
        Scanner tokens = new Scanner(line);
        if(!tokens.hasNext()){
            // Ignore an empty line
            return;
        }
        
        String first = tokens.next();
        if(!testFor.contains(first)){
            // Ignore this line
            System.out.println("Ignored:" + line);
        }
        
        // Figure out what to do
        
        if(first.equals("Customer:Constructor")){
            String name = tokens.next();
            int value = tokens.nextInt();
            
            printLineHeader(first + " " + name + " " + value, tokens);
            aCustomer = new Customer(name, value);
            System.out.println("Created customer " + aCustomer + "\n");
            
        }
        
        if(first.equals("Customer:getName")){
            printLineHeader(first, tokens);
            System.out.println("Customer name is " + aCustomer.getName() + "\n");
        }

        if(first.equals("Customer:getTransactionValue")){
            printLineHeader(first, tokens);
            System.out.println("Customer transaction value is " + aCustomer.getTransactionValue() + "\n");
        }

        if(first.equals("Customer:getWait")){
            printLineHeader(first, tokens);
            System.out.println("Customer wait time is " + aCustomer.getWait() + "\n");
        }

        if(first.equals("Customer:bumpWaitTime")){
            printLineHeader(first, tokens);
            aCustomer.bumpWaitTime();
            System.out.println("Customer wait time is " + aCustomer.getWait() + "\n");
        }
        
        if(first.equals("Customer:toString")){
            printLineHeader(first, tokens);
            System.out.println("Customer toString is  " + aCustomer + "\n");
        }

    }
    
    public static void printLineHeader(String test, Scanner s){
        String expected;
        if(s.hasNextLine()){
            expected = s.nextLine().trim();
        } else {
            expected =  "";
        }
            System.out.println("Testing " + test );
            System.out.println("EXPECTED: " + expected);
            System.out.print("RESULT:   ");
    }

}

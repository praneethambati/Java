/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labexam2practice;

import java.io.*;
import java.util.*;

/**
 *
 * @author HOOT
 */
public class TestBank {

    public static Set<String> testFor = new HashSet<String>();
    public static Customer aCustomer = null;
    public static Bank myBank = null;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {

        System.out.println("What is the name of the test script file? (ex: SmallBank.txt)");
        Scanner keyboard = new Scanner(System.in);
        String name = keyboard.next();

        Scanner in = new Scanner(new File(name));

        testFor.add("Bank:Constructor");
        testFor.add("Bank:addToLine");
        testFor.add("Bank:serve");
        testFor.add("Bank:bumpTime");
        testFor.add("Bank:averageWait");
        testFor.add("Bank:customersOver");

        while (in.hasNext()) {
            String line = in.nextLine();
            processLine(line);
        }
    }

    public static void processLine(String line) {
        Scanner tokens = new Scanner(line);
        if (!tokens.hasNext()) {
            // Ignore an empty line
            return;
        }

        String first = tokens.next();
        if (!testFor.contains(first)) {
            // Ignore this line
            System.out.println("Ignored:" + line);
        }

        // Figure out what to do
        if (first.equals("Bank:Constructor")) {

            printLineHeader(first, tokens);
            myBank = new Bank();
            System.out.println("Created Bank " + myBank + "\n");
        }

        if (first.equals("Bank:addToLine")) {
            String name = tokens.next();
            int amount = tokens.nextInt();

            printLineHeader(first + " " + name + " " + amount, tokens);
            myBank.addToLine(name, amount);
            System.out.println(myBank + "\n");
        }

        if (first.equals("Bank:serve")) {
            printLineHeader(first, tokens);
            String serve = myBank.serve();
            System.out.println("Serve returned " + serve);
            System.out.println("\t" + myBank +"\n");
        }

        if (first.equals("Bank:bumpTime")) {
            printLineHeader(first, tokens);
            myBank.bumpTime();
            System.out.println(myBank + "\n");
        }

        if (first.equals("Bank:averageWait")) {
            printLineHeader(first, tokens);
            double avg = myBank.averageWait();
            System.out.println("The average is " + avg + "\n");
        }

        if (first.equals("Bank:customersOver")) {
            int low = tokens.nextInt();
            printLineHeader(first+ " " + low, tokens);
            List<String> response = myBank.customersOver(low);
            System.out.println("Customer names returned " + response + "\n");
        }

    }
    
    public static void printLineHeader(String test, Scanner s){
        String expected;
        if(s.hasNextLine()){
            expected = s.nextLine().trim();
        } else {
            expected =  "";
        }
            System.out.println("Testing " + test );
            System.out.println("EXPECTED: " + expected);
            System.out.print("RESULT:   ");
 
        
    }

}

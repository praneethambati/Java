/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sortingandexceptions;

/**
 *
 * @author S524965
 */
public class ApartmentInsurance extends HouseInsurance{

    public ApartmentInsurance(String ownerName, String apartmentNumber, int yearsOfPayment, String ssn, String location) {
        super(ownerName, apartmentNumber, yearsOfPayment, ssn, location);
    }
    
    @Override
    public boolean equals(Object object){
        return super.getLocation().equals(((HouseInsurance)object).getLocation());
    }
    
}

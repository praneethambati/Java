/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sortingandexceptions;

/**
 *
 * @author S524965
 */
public class HouseInsurance implements PropertyInsurance,Comparable<HouseInsurance>{
    
    private String apartmentNumber;
    private String location;
    private String ownerName;
    private String ssn;
    private int totalYearsOfPayment;

    public HouseInsurance(String ownerName, String apartmentNumber,int totalYearsOfPayment,String ssn,String location) {
        this.apartmentNumber = apartmentNumber;
        this.location = location;
        this.ownerName = ownerName;
        this.ssn = ssn;
        this.totalYearsOfPayment = totalYearsOfPayment;
    }
    
    @Override
    public double calcLongTermPlan(int noOfYears) throws IncorrectYearsException{
        
        if(noOfYears==INSURANCE_DURATION){
           
           return (LONG_TERM_PLAN * noOfYears)+(LONG_TERM_PLAN * noOfYears*10/100);
        }
        else if(noOfYears<INSURANCE_DURATION){
            return calcLongTermPlan(noOfYears);
        }
        else{
            throw new IncorrectYearsException();
        }
        
            
    }
    
    @Override
    public double calcShortTermPlan(int noOfYears) throws IncorrectYearsException{
       
        if(noOfYears==4){
            return (LONG_TERM_PLAN*noOfYears)-(((20*LONG_TERM_PLAN)/100)*noOfYears);
        }
        else if(noOfYears==3){
            return  (LONG_TERM_PLAN*noOfYears)-(((23*LONG_TERM_PLAN)/100)*noOfYears);
        }
        else if(noOfYears==2){
            return  (LONG_TERM_PLAN*noOfYears)-(((25*LONG_TERM_PLAN)/100)*noOfYears);
        }
         else if(noOfYears==1){
            return (LONG_TERM_PLAN*noOfYears)-(((27*LONG_TERM_PLAN)/100)*noOfYears);
        }
         else if(noOfYears==INSURANCE_DURATION){
            return calcLongTermPlan(noOfYears);
        }
        else{
            throw new IncorrectYearsException("Value of repayment shouldn't be greater than the insurance duration or less than equal to zero.");
        }
        
    }
    
    @Override
    public int compareTo(HouseInsurance houseInsurance){
        return getApartmentNumber().compareTo(houseInsurance.getApartmentNumber());
    }
   
    public void checkSSNNumber(String ssn) throws NonDigitFoundException{
        if(!ssn.matches("[0-9]+")){
            throw new NonDigitFoundException("NonDigitFoundException: Some values in the SSN are not digits.");
        }
    }
    
    @Override
    public boolean equals(Object object){
        return getOwnerName().equals(((HouseInsurance)object).ownerName);
    }

    public String getApartmentNumber() {
        return apartmentNumber;
    }

    public void setApartmentNumber(String apartmentNumber) {
        this.apartmentNumber = apartmentNumber;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public int getTotalYearsOfPayment() {
        return totalYearsOfPayment;
    }

    public void setTotalYearsOfPayment(int totalYearsOfPayment) {
        this.totalYearsOfPayment = totalYearsOfPayment;
    }
    
    @Override
    public String toString(){
        
        return String.format("%-10s %-10s %3d %-10s %-10s %s-%s-%s", getOwnerName(),getApartmentNumber(),getTotalYearsOfPayment(),getSsn(),getLocation(),ssn.subSequence(0,3),ssn.subSequence(3,6),ssn.subSequence(6,10));
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sortingandexceptions;

/**
 *
 * @author S524965
 */
public class VehicleInsurance implements PropertyInsurance,Comparable<VehicleInsurance>{
    private String telephoneNumber;
    private int totalYearsOfPayment;
    private String vehicleMake;
    private String vehicleNumber;
    private String vehicleOwnerName;
    private int vehiclePurchaseYear;

    public VehicleInsurance(String vehicleOwnerName, String vehicleNumber, String vehicleMake, int vehiclePurchaseYear, int totalYearsOfPayment, String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
        this.totalYearsOfPayment = totalYearsOfPayment;
        this.vehicleMake = vehicleMake;
        this.vehicleNumber = vehicleNumber;
        this.vehicleOwnerName = vehicleOwnerName;
        this.vehiclePurchaseYear = vehiclePurchaseYear;
    }

    @Override
    public double calcShortTermPlan(int noOfYears) throws IncorrectYearsException {
        
        if(noOfYears==4){
            return (LONG_TERM_PLAN*noOfYears)-(((10*LONG_TERM_PLAN)/100)*noOfYears);
        }
        else if(noOfYears==3){
            return (LONG_TERM_PLAN*noOfYears)-(((15*LONG_TERM_PLAN)/100)*noOfYears);
        }
        else if(noOfYears==2){
            return (LONG_TERM_PLAN*noOfYears)-(((20*LONG_TERM_PLAN)/100)*noOfYears);
        }
         else if(noOfYears==1){
            return (LONG_TERM_PLAN*noOfYears)-(((25*LONG_TERM_PLAN)/100)*noOfYears);
        }
         else if(noOfYears==INSURANCE_DURATION){
           return calcLongTermPlan(noOfYears);
        }
        else{
            throw new IncorrectYearsException();
        }
       
    }

    @Override
    public double calcLongTermPlan(int noOfYears) throws IncorrectYearsException {
       
        if(noOfYears==INSURANCE_DURATION){
           
            return (LONG_TERM_PLAN * noOfYears)+(LONG_TERM_PLAN * noOfYears*10/100);
        }
        else if(noOfYears<INSURANCE_DURATION){
            return calcLongTermPlan(noOfYears);
        }
        else{
            throw new IncorrectYearsException();
        }
        
          
    }
    
    public void checkPhoneNumber(String telephoneNumber) throws IncorrectAreaCodeException,IncorrectLengthException,NonDigitFoundException{
        if(telephoneNumber.length()!=10){
            throw new IncorrectLengthException();
        }
        if(!telephoneNumber.matches("[^660]")||!telephoneNumber.matches("[^816]")){
            throw new IncorrectAreaCodeException("IncorrectAreaCodeException: Area code must be 660 or 816.");
        }
        if(!telephoneNumber.matches("[0-9]+")){
            throw new NonDigitFoundException("NonDigitFoundException: Some values in the telephoneNumber are not digits.");
        }
    }
    
      @Override
  public int compareTo(VehicleInsurance vehicleInsurance){
      
      return telephoneNumber.compareTo(vehicleInsurance.telephoneNumber);
  }

    public String getTelephoneNumber() {
        
        return telephoneNumber;
    }

    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public int getTotalYearsOfPayment() {
        return totalYearsOfPayment;
    }

    public void setTotalYearsOfPayment(int totalYearsOfPayment) {
        this.totalYearsOfPayment = totalYearsOfPayment;
    }

    public String getVehicleMake() {
        return vehicleMake;
    }

    public void setVehicleMake(String vehicleMake) {
        this.vehicleMake = vehicleMake;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public void setVehicleNumber(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }

    public String getVehicleOwnerName() {
        return vehicleOwnerName;
    }

    public void setVehicleOwnerName(String vehicleOwnerName) {
        this.vehicleOwnerName = vehicleOwnerName;
    }

    public int getVehiclePurchaseYear() {
        return vehiclePurchaseYear;
    }

    public void setVehiclePurchaseYear(int vehiclePurchaseYear) {
        this.vehiclePurchaseYear = vehiclePurchaseYear;
    }
    
    @Override
     public boolean equals(Object object){
       return getVehicleNumber().equals(((VehicleInsurance)object).vehicleNumber);
    }
    
    @Override
     public String toString(){
         return String.format("%-10s %-10s %-10s %3d %3d %s-%s-%s",getVehicleOwnerName(),getVehicleNumber(),getVehicleMake(),getVehiclePurchaseYear(),getTotalYearsOfPayment(),telephoneNumber.subSequence(0,3),telephoneNumber.subSequence(3,6),telephoneNumber.subSequence(6,10));
     }
}


Instructions for adding student files to your project:

1) Place the "faculty.txt" file in the project root folder. i.e. outside "src" folder in the project.
2) Place the "FacultyDriver.java" file in the "\Lastname_Lab04ArraysAndArrayList\src\faculty" folder 
   i.e. in the faculty pacakge where all your other classes are placed.